package com.example.touchmacro

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import android.content.Context

data class TouchEvent(
    val x: Float,
    val y: Float,
    val timeMs: Long,
    val action: Int
)

class TouchAccessibilityService : AccessibilityService() {
    companion object {
        var instance: TouchAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val events = mutableListOf<TouchEvent>()
    private var recording = false
    private var overlay: LinearLayout? = null
    private var windowManager: WindowManager? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        overlay?.let { windowManager?.removeView(it) }
        overlay = null
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun showControls() {
        if (overlay != null) return

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(4, 4, 4, 4)
            setBackgroundColor(0xDD202020.toInt())
        }

        fun addButton(text: String, action: () -> Unit) {
            box.addView(Button(this).apply {
                this.text = text
                setOnClickListener { action() }
            })
        }

        addButton("REC") { startRecording() }
        addButton("STOP") { stopRecording() }
        addButton("PLAY") { play() }
        addButton("CLEAR") { events.clear() }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        windowManager?.addView(box, params)
        overlay = box
    }

    private fun startRecording() {
        events.clear()
        recording = true
        Toast.makeText(this, "Recording started", Toast.LENGTH_SHORT).show()
    }

    private fun stopRecording() {
        recording = false
        Toast.makeText(this, "Recording stopped", Toast.LENGTH_SHORT).show()
    }

    private fun play() {
        Toast.makeText(
            this,
            "Playback engine placeholder — recording input from other apps requires a supported Android input mechanism.",
            Toast.LENGTH_LONG
        ).show()
    }
}