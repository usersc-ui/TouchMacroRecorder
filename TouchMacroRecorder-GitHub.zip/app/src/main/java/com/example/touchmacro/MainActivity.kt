package com.example.touchmacro

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 50, 40, 40)
        }
        root.addView(TextView(this).apply {
            text = "Touch Macro Recorder"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Record → play your touch macro. Enable Accessibility and Overlay first."
            textSize = 16f
        })
        root.addView(Button(this).apply {
            text = "Enable Accessibility"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Allow Overlay"
            setOnClickListener {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
            }
        })
        root.addView(Button(this).apply {
            text = "Show Recorder Controls"
            setOnClickListener {
                TouchAccessibilityService.instance?.showControls()
                    ?: Toast.makeText(this@MainActivity, "Enable Accessibility first.", Toast.LENGTH_LONG).show()
            }
        })
        setContentView(root)
    }
}